# A Simple Frontend Application For Registration And Login

html, css, bootstrap, javascript, jquery, fontawesome

# HTTP Request (POST, GET, DELETE, PUT)
jquery ajax

# To Run The App
1. run mysql server. like xampp-->mysql-->start
2. run "back-end" folder by terminal commands "npm install", and then "nodemon server.js" .
3. then the database and table will be created automatically. 
4. run front-end folder using Live Server. or, just double-click the "index.html" file.




